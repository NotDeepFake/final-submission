Smart Fitness app by Omri and Vlad as a part of the final project in Computer Science degree in Afeka College. 

to run this project you should:
1. Android Studio Iguana | 2023.2. 1
2. Andorid MobileEmulator 
3. unzip Fitness App
4. to run a Gradle build
5. to run the app.